# 🛡️ DFIR Metadata Investigator - Streamlit Edition

A comprehensive Digital Forensics and Incident Response (DFIR) tool built with Streamlit for analyzing file metadata, detecting duplicates, and performing forensic analysis on digital evidence.

## 🚀 Features

### 📁 Evidence Ingestion
- **Multi-file Upload**: Upload multiple files simultaneously for batch processing
- **Hash Calculation**: Automatic MD5, SHA1, and SHA256 hash computation
- **Metadata Extraction**: Extract EXIF data from images, PDF metadata, and more
- **Progress Tracking**: Real-time processing progress with status updates

### 📊 File Explorer Dashboard
- **Interactive File Table**: Sortable and searchable file listing
- **Advanced Search**: Search by filename, extension, or hash values
- **Detailed File View**: Complete metadata inspection for individual files
- **Export Capabilities**: CSV export for further analysis

### 📈 Metadata Pivot Analysis
- **Grouping Options**: Group files by extension, MIME type, camera make, software, etc.
- **Visual Analytics**: Interactive charts and pie charts for data distribution
- **Statistical Breakdown**: File count and size statistics per group
- **Drill-down Analysis**: Detailed view of files within each group

### 🔍 Hash Comparison & Duplicate Detection
- **Automatic Duplicate Detection**: SHA256-based duplicate file identification
- **Manual Comparison**: Side-by-side comparison of selected files
- **Hash Verification**: MD5, SHA1, and SHA256 hash matching analysis
- **Forensic Reporting**: Detailed duplicate analysis with timestamps

### 🤖 Machine Learning Clustering
- **Automated Clustering**: K-means clustering based on file size and timestamps
- **Anomaly Detection**: Identify unusual files that don't fit standard patterns
- **Pattern Recognition**: Group similar files for efficient analysis

## 🛠️ Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd dfir-metadata-investigator-model-main
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**:
   ```bash
   streamlit run app.py
   ```

4. **Access the application**:
   Open your browser and navigate to `http://localhost:8501`

## 📋 Requirements

- Python 3.8+
- Streamlit 1.28.0+
- pandas 2.0.0+
- scikit-learn 1.3.0+
- plotly 5.15.0+
- Pillow 10.0.0+
- exifread 3.0.0+
- PyPDF2 3.0.0+

## 🎯 Use Cases

### Digital Forensics
- **Evidence Processing**: Batch process digital evidence files
- **Timeline Analysis**: Analyze file creation and modification patterns
- **Duplicate Detection**: Identify copied or moved files
- **Metadata Forensics**: Extract hidden information from file metadata

### Incident Response
- **Rapid Triage**: Quick analysis of suspicious files
- **Pattern Detection**: Identify unusual file patterns or anomalies
- **Hash Verification**: Verify file integrity using cryptographic hashes
- **Reporting**: Generate detailed forensic reports

### Security Analysis
- **Malware Analysis**: Analyze file characteristics and metadata
- **Data Leakage Detection**: Identify duplicate sensitive files
- **Compliance Auditing**: Verify file handling procedures

## 🔧 Technical Features

### Supported File Types
- **Images**: JPEG, PNG, TIFF, BMP, WebP, HEIC
- **Documents**: PDF, DOC, DOCX
- **Archives**: ZIP, RAR, 7Z
- **Executables**: EXE, DLL
- **General**: Any file type for hash analysis

### Metadata Extraction
- **EXIF Data**: Camera settings, GPS coordinates, timestamps
- **PDF Metadata**: Author, creator, producer, creation date
- **System Metadata**: File size, modification dates, MIME types
- **Custom Fields**: Extensible metadata extraction framework

### Security Features
- **Hash Verification**: Multiple hash algorithms for integrity checking
- **Secure Processing**: Files processed in memory without permanent storage
- **Privacy Protection**: No data transmitted externally
- **Audit Trail**: Complete processing history and statistics

## 📊 Interface Overview

### 1. Upload View
- Drag-and-drop file upload interface
- Progress tracking with real-time status
- Batch processing capabilities
- Error handling and validation

### 2. Dashboard View
- Comprehensive file listing with sorting and filtering
- Search functionality across all file attributes
- Detailed metadata viewer for individual files
- Export options for analysis results

### 3. Grouping View
- Interactive pivot analysis with multiple grouping options
- Visual charts showing data distribution
- Statistical summaries and breakdowns
- Drill-down capabilities for detailed analysis

### 4. Comparison View
- Automated duplicate detection with detailed reporting
- Manual file comparison with hash verification
- Side-by-side metadata comparison
- Forensic analysis results

## 🚀 Getting Started

1. **Launch the application** using `streamlit run app.py`
2. **Upload files** using the Evidence Ingestion interface
3. **Explore data** using the Dashboard for file overview
4. **Analyze patterns** using the Grouping view for pivot analysis
5. **Detect duplicates** using the Comparison view for forensic analysis
6. **Export results** for further investigation or reporting

## 🔒 Security Considerations

- All file processing occurs locally on your machine
- No data is transmitted to external servers
- Files are processed in memory and not permanently stored
- Hash calculations use industry-standard algorithms
- Metadata extraction respects privacy and security requirements

## 🤝 Contributing

This tool is designed for digital forensics professionals and security analysts. Contributions are welcome for:
- Additional metadata extraction capabilities
- New file format support
- Enhanced visualization features
- Performance optimizations
- Security improvements

## 📄 License

This project is intended for legitimate digital forensics and security analysis purposes. Please ensure compliance with applicable laws and regulations when analyzing digital evidence.

---

**⚠️ Disclaimer**: This tool is designed for legitimate digital forensics and incident response activities. Users are responsible for ensuring compliance with applicable laws and regulations when analyzing digital evidence.