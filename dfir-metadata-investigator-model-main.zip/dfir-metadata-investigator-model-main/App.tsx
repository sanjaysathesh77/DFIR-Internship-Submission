
import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { FileTable } from './components/FileTable';
import { HashComparator } from './components/HashComparator';
import { MetadataPivot } from './components/MetadataPivot';
import { FileMetadata, AppView, ProcessingStats } from './types';
import { processFile } from './utils/fileProcessor';
import { performClustering } from './utils/clustering';
import { Icons } from './utils/icons';

export default function App() {
  const [files, setFiles] = useState<FileMetadata[]>([]);
  const [view, setView] = useState<AppView>(AppView.UPLOAD);
  const [stats, setStats] = useState<ProcessingStats>({ totalFiles: 0, processedCount: 0, isProcessing: false });
  const [clusters, setClusters] = useState<any[]>([]);

  // Handler for folder upload
  const handleFolderSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = event.target.files;
    if (!fileList || fileList.length === 0) return;

    setStats({ totalFiles: fileList.length, processedCount: 0, isProcessing: true });
    setFiles([]); // Reset

    const newFiles: FileMetadata[] = [];
    
    // Process in chunks to avoid freezing UI
    const chunkSize = 10;
    const allFiles = Array.from(fileList);
    
    for (let i = 0; i < allFiles.length; i += chunkSize) {
      const chunk = allFiles.slice(i, i + chunkSize);
      const processedChunk = await Promise.all(chunk.map(f => processFile(f)));
      newFiles.push(...processedChunk);
      
      setStats(prev => ({ ...prev, processedCount: prev.processedCount + chunk.length }));
      // Yield to event loop
      await new Promise(r => setTimeout(r, 0));
    }

    // Run Clustering
    const clusteringResult = performClustering(newFiles);
    setFiles(clusteringResult.files);
    setClusters(clusteringResult.clusters);

    setStats(prev => ({ ...prev, isProcessing: false }));
    setView(AppView.DASHBOARD);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const fileList = e.dataTransfer.files;
    if(fileList.length > 0) {
         setStats({ totalFiles: fileList.length, processedCount: 0, isProcessing: true });
         setFiles([]);
         const newFiles: FileMetadata[] = [];
         const allFiles = Array.from(fileList);
         for (let i = 0; i < allFiles.length; i++) {
             newFiles.push(await processFile(allFiles[i]));
             setStats(prev => ({ ...prev, processedCount: i + 1 }));
         }
         const clusteringResult = performClustering(newFiles);
         setFiles(clusteringResult.files);
         setClusters(clusteringResult.clusters);
         setStats({ totalFiles: fileList.length, processedCount: fileList.length, isProcessing: false });
         setView(AppView.DASHBOARD);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden">
      <Sidebar files={files} currentView={view} onChangeView={setView} />
      
      <main className="flex-1 ml-64 p-8 h-full overflow-hidden relative">
        
        {view === AppView.UPLOAD && (
          <div 
            className="h-full flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-xl bg-slate-900/30 p-12"
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            {stats.isProcessing ? (
              <div className="text-center">
                <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
                <h2 className="text-2xl font-bold text-slate-100 mb-2">Ingesting Evidence...</h2>
                <p className="text-slate-400">Processed {stats.processedCount} of {stats.totalFiles} files</p>
                <div className="w-64 h-2 bg-slate-800 rounded mt-4 overflow-hidden">
                    <div 
                        className="h-full bg-cyan-500 transition-all duration-200" 
                        style={{ width: `${stats.totalFiles > 0 ? (stats.processedCount / stats.totalFiles) * 100 : 0}%`}}
                    ></div>
                </div>
              </div>
            ) : (
              <div className="text-center">
                <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 text-cyan-500">
                  <Icons.Upload className="w-10 h-10" />
                </div>
                <h2 className="text-3xl font-bold text-slate-100 mb-4">Evidence Ingestion</h2>
                <p className="text-slate-400 max-w-md mx-auto mb-8">
                  Upload a folder to begin forensic analysis. 
                  System will extract metadata, compute hashes (MD5/SHA), and cluster files.
                </p>
                
                <label className="cursor-pointer bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-3 rounded-lg font-bold transition-colors shadow-lg shadow-cyan-900/20 flex items-center gap-2 mx-auto w-fit">
                    <Icons.FolderSearch className="w-5 h-5" />
                    Select Evidence Folder
                    <input 
                        type="file" 
                        className="hidden" 
                        {...({ webkitdirectory: "", directory: "" } as any)}
                        multiple 
                        onChange={handleFolderSelect} 
                    />
                </label>
                <p className="mt-6 text-xs text-slate-500">
                  Supports Recursive Scan • Hash Calculation • ExifTool Extraction • Anomaly Detection
                </p>
              </div>
            )}
          </div>
        )}

        {view === AppView.DASHBOARD && (
            <FileTable files={files} />
        )}

        {view === AppView.GROUPING && (
            <MetadataPivot files={files} />
        )}

        {view === AppView.COMPARE && (
            <HashComparator files={files} />
        )}

      </main>
    </div>
  );
}