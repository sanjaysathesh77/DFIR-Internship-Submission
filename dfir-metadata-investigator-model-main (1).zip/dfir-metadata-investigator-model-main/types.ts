
export interface FileMetadata {
  id: string;
  name: string;
  path: string;
  size: number;
  type: string;
  extension: string;
  lastModified: number;
  sha1: string;
  sha256?: string;
  md5?: string;
  clusterId?: number;
  metadata: Record<string, string | number | boolean>;
}

export interface FileCluster {
  id: number;
  centroid: { x: number; y: number }; // Normalized Size vs Time
  fileIds: string[];
  label?: string;
}

export enum AppView {
  UPLOAD = 'UPLOAD',
  DASHBOARD = 'DASHBOARD',
  COMPARE = 'COMPARE',
  GROUPING = 'GROUPING'
}

export interface ProcessingStats {
  totalFiles: number;
  processedCount: number;
  isProcessing: boolean;
}

export const FILE_TYPES_INTEREST = ['image/jpeg', 'image/png', 'application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];