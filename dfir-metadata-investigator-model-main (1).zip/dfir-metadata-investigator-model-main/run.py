#!/usr/bin/env python3

import subprocess
import sys
import os
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are installed."""
    required_packages = [
        'streamlit', 'pandas', 'scikit-learn', 'plotly', 
        'pillow', 'exifread', 'PyPDF2'
    ]
    
    missing_packages = []
    for package in required_packages:
        try:
            __import__(package.replace('-', '_').lower())
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print("❌ Missing required packages:")
        for package in missing_packages:
            print(f"   - {package}")
        print("\n📦 Install missing packages with:")
        print("   pip install -r requirements.txt")
        return False
    
    print("✅ All dependencies are installed!")
    return True

def launch_streamlit():
    """Launch the Streamlit application."""
    app_path = Path(__file__).parent / "app.py"
    
    if not app_path.exists():
        print("❌ app.py not found in the current directory!")
        return False
    
    print("🚀 Launching DFIR Metadata Investigator...")
    print("📱 The application will open in your default web browser")
    print("🌐 URL: http://localhost:8501")
    print("⏹️  Press Ctrl+C to stop the application")
    print("-" * 50)
    
    try:
        # Launch Streamlit with custom configuration
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", str(app_path),
            "--server.headless", "false",
            "--server.port", "8501",
            "--server.address", "localhost",
            "--theme.base", "dark",
            "--theme.primaryColor", "#00d4ff",
            "--theme.backgroundColor", "#0e1117",
            "--theme.secondaryBackgroundColor", "#262730"
        ])
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    except Exception as e:
        print(f"❌ Error launching application: {e}")
        return False
    
    return True

def main():
    """Main function to run the launcher."""
    print("🛡️  DFIR Metadata Investigator - Streamlit Edition")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not Path("app.py").exists():
        print("❌ Please run this script from the project directory containing app.py")
        sys.exit(1)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Launch the application
    if not launch_streamlit():
        sys.exit(1)

if __name__ == "__main__":
    main()