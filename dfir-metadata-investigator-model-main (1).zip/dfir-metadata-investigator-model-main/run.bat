@echo off
title DFIR Metadata Investigator - Streamlit Edition

echo.
echo ===============================================
echo 🛡️  DFIR Metadata Investigator
echo    Streamlit Edition
echo ===============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed or not in PATH
    echo Please install Python 3.8+ and try again
    pause
    exit /b 1
)

REM Check if app.py exists
if not exist "app.py" (
    echo ❌ app.py not found in current directory
    echo Please run this script from the project folder
    pause
    exit /b 1
)

REM Install dependencies if requirements.txt exists
if exist "requirements.txt" (
    echo 📦 Installing/updating dependencies...
    pip install -r requirements.txt
    if errorlevel 1 (
        echo ❌ Failed to install dependencies
        pause
        exit /b 1
    )
    echo ✅ Dependencies installed successfully
    echo.
)

echo 🚀 Starting DFIR Metadata Investigator...
echo 📱 The application will open in your web browser
echo 🌐 URL: http://localhost:8501
echo ⏹️  Press Ctrl+C to stop the application
echo.
echo ===============================================
echo.

REM Launch Streamlit
streamlit run app.py --server.headless false --server.port 8501 --theme.base dark --theme.primaryColor "#00d4ff"

echo.
echo 👋 Application stopped
pause