#  DFIR Metadata Investigator - Streamlit Edition


## Requirements

- Python 3.8+
- Streamlit 1.28.0+
- pandas 2.0.0+
- scikit-learn 1.3.0+
- plotly 5.15.0+
- Pillow 10.0.0+
- exifread 3.0.0+
- PyPDF2 3.0.0+

##  Use Cases

### Digital Forensics
- Evidence Processing: Batch process digital evidence files
- Timeline Analysis: Analyze file creation and modification patterns
- Duplicate Detection: Identify copied or moved files
- Metadata Forensics: Extract hidden information from file metadata

### Incident Response
- Rapid Triage: Quick analysis of suspicious files
- Pattern Detection: Identify unusual file patterns or anomalies
- Hash Verification: Verify file integrity using cryptographic hashes
- Reporting: Generate detailed forensic reports



## Technical Features

### Supported File Types
- Images: JPEG, PNG, TIFF, BMP, WebP, HEIC
- Documents: PDF, DOC, DOCX
- *Archives: ZIP, RAR, 7Z
- Executables: EXE, DLL
- General: Any file type for hash analysis

### Metadata Extraction
- EXIF Data: Camera settings, GPS coordinates, timestamps
- PDF Metadata: Author, creator, producer, creation date
- System Metadata: File size, modification dates, MIME types
  Custom Fields: Extensible metadata extraction framework


## Interface Overview

### 1. Upload View
- Drag-and-drop file upload interface
- Progress tracking with real-time status
- Batch processing capabilities
- Error handling and validation

### 2. Dashboard View
- Comprehensive file listing with sorting and filtering
- Search functionality across all file attributes
- Detailed metadata viewer for individual files
- Export options for analysis results

### 3. Grouping View
- Interactive pivot analysis with multiple grouping options
- Visual charts showing data distribution
- Statistical summaries and breakdowns
- Drill-down capabilities for detailed analysis

### 4. Comparison View
- Automated duplicate detection with detailed reporting
- Manual file comparison with hash verification
- Side-by-side metadata comparison
- Forensic analysis results