import { FileMetadata, FileCluster } from '../types';

// Simple K-Means implementation
export function performClustering(files: FileMetadata[], k: number = 4): { clusters: FileCluster[], files: FileMetadata[] } {
  if (files.length === 0) return { clusters: [], files: [] };

  // Feature Extraction: 
  // 1. Normalized Log Size
  // 2. Normalized Time (Last Modified)
  
  const maxSize = Math.max(...files.map(f => Math.log(f.size + 1)));
  const minSize = Math.min(...files.map(f => Math.log(f.size + 1)));
  
  const maxTime = Math.max(...files.map(f => f.lastModified));
  const minTime = Math.min(...files.map(f => f.lastModified));

  const normalizeSize = (s: number) => (Math.log(s + 1) - minSize) / (maxSize - minSize || 1);
  const normalizeTime = (t: number) => (t - minTime) / (maxTime - minTime || 1);

  const vectors = files.map(f => ({
    id: f.id,
    x: normalizeSize(f.size),
    y: normalizeTime(f.lastModified)
  }));

  // Initialize Centroids randomly
  let centroids = Array.from({ length: k }, () => ({
    x: Math.random(),
    y: Math.random()
  }));

  let assignments: number[] = new Array(files.length).fill(-1);
  let iterations = 0;
  let changed = true;

  while (changed && iterations < 20) {
    changed = false;
    // Assign points to nearest centroid
    assignments = vectors.map((v, idx) => {
      let minDist = Infinity;
      let clusterIdx = -1;
      centroids.forEach((c, i) => {
        const dist = Math.sqrt(Math.pow(v.x - c.x, 2) + Math.pow(v.y - c.y, 2));
        if (dist < minDist) {
          minDist = dist;
          clusterIdx = i;
        }
      });
      if (assignments[idx] !== clusterIdx) changed = true;
      return clusterIdx;
    });

    // Update Centroids
    centroids = centroids.map((c, i) => {
      const clusterPoints = vectors.filter((_, idx) => assignments[idx] === i);
      if (clusterPoints.length === 0) return c; // Keep old if empty
      const avgX = clusterPoints.reduce((sum, p) => sum + p.x, 0) / clusterPoints.length;
      const avgY = clusterPoints.reduce((sum, p) => sum + p.y, 0) / clusterPoints.length;
      return { x: avgX, y: avgY };
    });

    iterations++;
  }

  // Map back to structure
  const clusters: FileCluster[] = centroids.map((c, i) => ({
    id: i,
    centroid: c,
    fileIds: files.filter((_, idx) => assignments[idx] === i).map(f => f.id),
    label: `Cluster ${i + 1}`
  })).filter(c => c.fileIds.length > 0);

  const updatedFiles = files.map((f, i) => ({
    ...f,
    clusterId: assignments[i]
  }));

  return { clusters, files: updatedFiles };
}
