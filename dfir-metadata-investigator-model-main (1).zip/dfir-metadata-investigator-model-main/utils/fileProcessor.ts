
import { FileMetadata } from '../types';

declare global {
  interface Window {
    SparkMD5: any;
  }
}

export async function processFile(file: File): Promise<FileMetadata> {
  const arrayBuffer = await file.arrayBuffer();
  
  // Compute SHA-1 Hash (SubtleCrypto)
  const hashBuffer = await crypto.subtle.digest('SHA-1', arrayBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const sha1 = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

  // Compute SHA-256 Hash (SubtleCrypto)
  const hashBuffer256 = await crypto.subtle.digest('SHA-256', arrayBuffer);
  const hashArray256 = Array.from(new Uint8Array(hashBuffer256));
  const sha256 = hashArray256.map(b => b.toString(16).padStart(2, '0')).join('');

  // Compute MD5 using SparkMD5 (if available via CDN)
  let md5 = '';
  if (window.SparkMD5) {
    const spark = new window.SparkMD5.ArrayBuffer();
    spark.append(arrayBuffer);
    md5 = spark.end();
  } else {
    md5 = 'MD5-Lib-Missing';
  }

  // Basic Metadata
  const extension = file.name.split('.').pop()?.toLowerCase() || 'unknown';
  const path = (file as any).webkitRelativePath || file.name;

  // Simulate ExifTool Extraction
  // In a real app, we would use a WASM build of ExifTool or a parser library.
  // Here we generate realistic structure based on file type.
  const metadata: Record<string, string | number | boolean> = {
    'System:FileSize': file.size,
    'System:FileName': file.name,
    'System:MIMEType': file.type,
    'System:FileModifyDate': new Date(file.lastModified).toISOString(),
  };

  // Randomized simulated data for demo purposes to enable clustering/anomaly detection
  if (['jpg', 'jpeg', 'png', 'webp', 'heic'].includes(extension)) {
    const makes = ['Canon', 'Nikon', 'Sony', 'Apple'];
    const make = makes[Math.floor(Math.random() * 4)];
    metadata['EXIF:Make'] = make;
    metadata['EXIF:Model'] = make === 'Apple' ? 'iPhone 13 Pro' : make === 'Sony' ? 'Alpha a7 III' : 'EOS R5';
    metadata['EXIF:Software'] = Math.random() > 0.5 ? 'Adobe Photoshop 2023' : 'Ver.1.0.2';
    metadata['Composite:ImageSize'] = '1920x1080';
    metadata['EXIF:ColorSpace'] = 'sRGB';
    
    // Capture Details
    metadata['EXIF:DateTimeOriginal'] = new Date(file.lastModified - 100000000).toISOString().replace(/T/, ' ').slice(0, 19);
    metadata['EXIF:CreateDate'] = new Date(file.lastModified - 50000000).toISOString().replace(/T/, ' ').slice(0, 19);
    metadata['EXIF:ModifyDate'] = new Date(file.lastModified).toISOString().replace(/T/, ' ').slice(0, 19);
    metadata['EXIF:ISO'] = [100, 200, 400, 800, 1600][Math.floor(Math.random() * 5)];
    metadata['EXIF:ExposureTime'] = '1/' + [60, 125, 250, 500, 1000][Math.floor(Math.random() * 5)];
    metadata['EXIF:FNumber'] = [1.8, 2.8, 4.0, 5.6][Math.floor(Math.random() * 4)];

    // GPS
    if (Math.random() > 0.3) {
        metadata['EXIF:GPSLatitude'] = 37.7749 + (Math.random() - 0.5);
        metadata['EXIF:GPSLongitude'] = -122.4194 + (Math.random() - 0.5);
        metadata['EXIF:GPSAltitude'] = Math.floor(Math.random() * 100) + ' m';
    }
  } else if (extension === 'pdf') {
    metadata['PDF:Producer'] = 'Adobe PDF Library 15.0';
    metadata['PDF:PageCount'] = Math.floor(Math.random() * 50) + 1;
    metadata['PDF:Author'] = 'Unknown User';
    metadata['PDF:CreateDate'] = new Date(file.lastModified).toISOString();
  } else if (['doc', 'docx'].includes(extension)) {
    metadata['Office:Creator'] = 'Microsoft Office Word';
    metadata['Office:LastModifiedBy'] = 'Administrator';
    metadata['Office:RevisionNumber'] = Math.floor(Math.random() * 10);
    metadata['Office:CreateDate'] = new Date(file.lastModified - 86400000).toISOString();
  }

  return {
    id: crypto.randomUUID(),
    name: file.name,
    path: path,
    size: file.size,
    type: file.type || 'application/octet-stream',
    extension,
    lastModified: file.lastModified,
    sha1,
    sha256,
    md5,
    metadata
  };
}

export function formatBytes(bytes: number, decimals = 2) {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
