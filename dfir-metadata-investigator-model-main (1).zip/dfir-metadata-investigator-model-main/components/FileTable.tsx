
import React, { useState, useMemo } from 'react';
import { FileMetadata } from '../types';
import { formatBytes } from '../utils/fileProcessor';
import { Icons } from '../utils/icons';

interface FileTableProps {
  files: FileMetadata[];
}

const ExifDataRow = ({ label, value }: { label: string, value: any }) => (
    <div className="flex justify-between items-center py-2 border-b border-slate-800/50 last:border-0 text-xs group">
        <span className="text-slate-500 font-medium group-hover:text-slate-400 transition-colors">{label}</span>
        <span className="text-slate-300 font-mono text-right max-w-[150px] truncate" title={String(value)}>
            {value !== undefined && value !== null ? String(value) : <span className="text-slate-700 italic">( none )</span>}
        </span>
    </div>
);

const ExifSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
    <div className="bg-slate-950/50 rounded-lg border border-slate-800 overflow-hidden mb-4">
        <div className="bg-slate-900/80 px-3 py-2 text-xs font-bold text-cyan-500 uppercase tracking-wider border-b border-slate-800">
            {title}
        </div>
        <div className="p-3">
            {children}
        </div>
    </div>
);

export const FileTable: React.FC<FileTableProps> = ({ files }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof FileMetadata>('size');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [selectedFile, setSelectedFile] = useState<FileMetadata | null>(null);

  const filteredFiles = useMemo(() => {
    return files.filter(f => 
      f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.extension.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.sha1?.includes(searchTerm.toLowerCase()) ||
      f.md5?.includes(searchTerm.toLowerCase())
    );
  }, [files, searchTerm]);

  const sortedFiles = useMemo(() => {
    return [...filteredFiles].sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      if (valA === undefined || valB === undefined) return 0;

      if (valA < valB) return sortDir === 'asc' ? -1 : 1;
      if (valA > valB) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredFiles, sortField, sortDir]);

  const handleSort = (field: keyof FileMetadata) => {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const exportCSV = () => {
    const headers = ['Name', 'Path', 'Size', 'Extension', 'Created', 'MD5', 'SHA1', 'SHA256'];
    const rows = sortedFiles.map(f => [
      f.name,
      f.path,
      f.size,
      f.extension,
      new Date(f.lastModified).toISOString(),
      f.md5 || '',
      f.sha1,
      f.sha256 || ''
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "dfir_metadata_export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Simulated Parquet Export
  const exportParquetSim = () => {
    const exportData = {
        _meta: {
            format: "parquet-simulated-json",
            generator: "DFIR-Investigator",
            timestamp: new Date().toISOString()
        },
        schema: {
            name: "UTF8",
            path: "UTF8",
            size: "INT64",
            md5: "UTF8",
            metadata: "MAP<STRING, STRING>"
        },
        rows: sortedFiles
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
    const link = document.createElement("a");
    link.setAttribute("href", dataStr);
    link.setAttribute("download", "dfir_metadata_export.json");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const isImage = (f: FileMetadata) => ['jpg', 'jpeg', 'png', 'webp', 'heic'].includes(f.extension);

  return (
    <div className="flex flex-col h-full relative">
      <div className="flex justify-between items-center mb-4">
        <div className="relative w-96">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icons.FolderSearch className="h-4 w-4 text-slate-500" />
          </div>
          <input
            type="text"
            placeholder="Search (Name, Ext, MD5, SHA1)..."
            className="pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 focus:ring-2 focus:ring-cyan-500 focus:border-transparent w-full text-sm placeholder-slate-600"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
            <button onClick={exportCSV} className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm transition-colors">
                <Icons.Download className="w-4 h-4" />
                Export CSV
            </button>
            <button onClick={exportParquetSim} className="flex items-center gap-2 px-4 py-2 bg-cyan-900/30 hover:bg-cyan-900/50 text-cyan-400 border border-cyan-900 rounded-lg text-sm transition-colors">
                <Icons.Download className="w-4 h-4" />
                Export JSON (Parquet Sim)
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto border border-slate-800 rounded-lg bg-slate-900/50">
        <table className="w-full text-left text-sm text-slate-400">
          <thead className="bg-slate-900 text-slate-200 sticky top-0 z-10">
            <tr>
              <th onClick={() => handleSort('name')} className="px-4 py-3 font-semibold cursor-pointer hover:text-cyan-400">Filename</th>
              <th onClick={() => handleSort('path')} className="px-4 py-3 font-semibold cursor-pointer hover:text-cyan-400">Path</th>
              <th onClick={() => handleSort('size')} className="px-4 py-3 font-semibold cursor-pointer hover:text-cyan-400">Size</th>
              <th onClick={() => handleSort('lastModified')} className="px-4 py-3 font-semibold cursor-pointer hover:text-cyan-400">Modified</th>
              <th className="px-4 py-3 font-semibold">MD5 Hash</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {sortedFiles.map((file) => (
              <tr 
                key={file.id} 
                onClick={() => setSelectedFile(file)}
                className="hover:bg-slate-800/50 transition-colors cursor-pointer"
              >
                <td className="px-4 py-2 font-medium text-slate-200 truncate max-w-[200px]" title={file.name}>{file.name}</td>
                <td className="px-4 py-2 truncate max-w-[250px] text-xs" title={file.path}>{file.path}</td>
                <td className="px-4 py-2 font-mono text-xs">{formatBytes(file.size)}</td>
                <td className="px-4 py-2 text-xs">{new Date(file.lastModified).toLocaleString()}</td>
                <td className="px-4 py-2 font-mono text-[10px] text-slate-500 truncate max-w-[100px]" title={file.md5}>{file.md5}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-2 text-xs text-slate-500 px-2">
        Showing {sortedFiles.length} files. Click row for details.
      </div>

      {/* File Detail Modal */}
      {selectedFile && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-8">
              <div className="bg-slate-900 border border-slate-700 rounded-xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl">
                  
                  {/* Modal Header */}
                  <div className="flex justify-between items-center p-6 border-b border-slate-800">
                      <div className="flex items-center gap-4">
                          <div className={`p-3 rounded-lg ${isImage(selectedFile) ? 'bg-cyan-900/20 text-cyan-400' : 'bg-slate-800 text-slate-400'}`}>
                              {isImage(selectedFile) ? <Icons.ScatterChart className="w-6 h-6" /> : <Icons.FileText className="w-6 h-6" />}
                          </div>
                          <div>
                              <h2 className="text-xl font-bold text-slate-100 break-all">{selectedFile.name}</h2>
                              <p className="text-sm text-slate-500 font-mono mt-1">{selectedFile.path}</p>
                          </div>
                      </div>
                      <button onClick={() => setSelectedFile(null)} className="text-slate-400 hover:text-white transition-colors p-2 hover:bg-slate-800 rounded-full">
                          <Icons.X className="w-6 h-6" />
                      </button>
                  </div>

                  {/* Modal Content */}
                  <div className="p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-2 gap-8">
                      
                      {/* Left Column: Basic Info & Hashes */}
                      <div className="space-y-6">
                          <div>
                              <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">File System Metadata</h3>
                              <dl className="space-y-3 text-sm">
                                  <div className="grid grid-cols-3 py-1">
                                      <dt className="text-slate-500">Size</dt>
                                      <dd className="col-span-2 text-slate-200 font-mono">{formatBytes(selectedFile.size)} ({selectedFile.size} bytes)</dd>
                                  </div>
                                  <div className="grid grid-cols-3 py-1">
                                      <dt className="text-slate-500">MIME Type</dt>
                                      <dd className="col-span-2 text-slate-200">{selectedFile.type}</dd>
                                  </div>
                                  <div className="grid grid-cols-3 py-1">
                                      <dt className="text-slate-500">Modified</dt>
                                      <dd className="col-span-2 text-slate-200">{new Date(selectedFile.lastModified).toLocaleString()}</dd>
                                  </div>
                                  <div className="grid grid-cols-3 py-1">
                                      <dt className="text-slate-500">Extension</dt>
                                      <dd className="col-span-2 text-slate-200 uppercase badge bg-slate-800 px-2 py-0.5 rounded w-fit text-xs">{selectedFile.extension}</dd>
                                  </div>
                              </dl>
                          </div>

                          <div>
                              <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">Cryptographic Hashes</h3>
                              <dl className="space-y-4 text-sm">
                                  <div>
                                      <dt className="text-slate-500 text-xs mb-1">MD5</dt>
                                      <dd className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-xs text-green-400 break-all selection:bg-green-900 selection:text-white">{selectedFile.md5}</dd>
                                  </div>
                                  <div>
                                      <dt className="text-slate-500 text-xs mb-1">SHA-1</dt>
                                      <dd className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-xs text-cyan-400 break-all selection:bg-cyan-900 selection:text-white">{selectedFile.sha1}</dd>
                                  </div>
                                  <div>
                                      <dt className="text-slate-500 text-xs mb-1">SHA-256</dt>
                                      <dd className="bg-slate-950 p-2 rounded border border-slate-800 font-mono text-[10px] text-slate-300 break-all selection:bg-slate-700">{selectedFile.sha256}</dd>
                                  </div>
                              </dl>
                          </div>
                      </div>

                      {/* Right Column: Extended Metadata */}
                      <div className="flex flex-col h-full">
                          
                          {/* IMAGE SPECIFIC EXIF SECTION (COLLAPSIBLE) */}
                          {isImage(selectedFile) && (
                            <details className="group mb-6" open>
                                <summary className="flex items-center justify-between cursor-pointer bg-cyan-900/20 p-3 rounded-t-lg border border-cyan-900/30 hover:bg-cyan-900/30 transition-colors">
                                    <div className="flex items-center gap-2 font-semibold text-cyan-400">
                                        <Icons.ScatterChart className="w-4 h-4" />
                                        <span>Image Metadata (EXIF)</span>
                                    </div>
                                    <span className="text-cyan-500 transform group-open:rotate-180 transition-transform">▼</span>
                                </summary>
                                <div className="bg-slate-900/50 border border-t-0 border-slate-800 rounded-b-lg p-4 space-y-4">
                                    
                                    <ExifSection title="Camera & Device Information">
                                        <ExifDataRow label="Make" value={selectedFile.metadata['EXIF:Make']} />
                                        <ExifDataRow label="Model" value={selectedFile.metadata['EXIF:Model']} />
                                        <ExifDataRow label="Software" value={selectedFile.metadata['EXIF:Software']} />
                                        <ExifDataRow label="Lens Model" value={selectedFile.metadata['EXIF:LensModel']} />
                                    </ExifSection>

                                    <ExifSection title="Image Information">
                                        <ExifDataRow label="Resolution" value={selectedFile.metadata['Composite:ImageSize']} />
                                        <ExifDataRow label="Color Space" value={selectedFile.metadata['EXIF:ColorSpace']} />
                                        <ExifDataRow label="MIME Type" value={selectedFile.type} />
                                    </ExifSection>

                                    <ExifSection title="Capture Details">
                                        <ExifDataRow label="DateTimeOriginal" value={selectedFile.metadata['EXIF:DateTimeOriginal']} />
                                        <ExifDataRow label="CreateDate" value={selectedFile.metadata['EXIF:CreateDate']} />
                                        <ExifDataRow label="ModifyDate" value={selectedFile.metadata['EXIF:ModifyDate']} />
                                        <ExifDataRow label="Exposure Time" value={selectedFile.metadata['EXIF:ExposureTime']} />
                                        <ExifDataRow label="F-Number" value={selectedFile.metadata['EXIF:FNumber']} />
                                        <ExifDataRow label="ISO" value={selectedFile.metadata['EXIF:ISO']} />
                                    </ExifSection>

                                    <ExifSection title="GPS Information">
                                        <ExifDataRow label="Latitude" value={selectedFile.metadata['EXIF:GPSLatitude']} />
                                        <ExifDataRow label="Longitude" value={selectedFile.metadata['EXIF:GPSLongitude']} />
                                        <ExifDataRow label="Altitude" value={selectedFile.metadata['EXIF:GPSAltitude']} />
                                    </ExifSection>

                                </div>
                            </details>
                          )}

                          {/* RAW METADATA VIEW */}
                          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4 border-b border-slate-800 pb-2 flex justify-between items-center">
                              <span>Raw Extracted Metadata</span>
                              <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400">ExifTool Output</span>
                          </h3>
                          <div className="bg-slate-950 rounded-lg p-4 font-mono text-xs text-slate-300 overflow-auto flex-1 max-h-[300px] border border-slate-800 shadow-inner">
                              {Object.entries(selectedFile.metadata).length > 0 ? (
                                Object.entries(selectedFile.metadata).map(([k, v]) => (
                                  <div key={k} className="flex mb-1 hover:bg-slate-900/50 px-1 -mx-1 rounded">
                                      <span className="text-cyan-600 min-w-[180px] block truncate mr-2" title={k}>{k}</span> 
                                      <span className="text-slate-400 break-all">{String(v)}</span>
                                  </div>
                                ))
                              ) : (
                                <div className="text-center text-slate-600 italic py-8">No additional metadata extracted.</div>
                              )}
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
