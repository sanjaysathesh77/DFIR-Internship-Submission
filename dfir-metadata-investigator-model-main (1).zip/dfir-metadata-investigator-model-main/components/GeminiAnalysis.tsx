import React, { useState, useEffect, useRef } from 'react';
import { FileMetadata, FileCluster } from '../types';
import { GoogleGenAI } from "@google/genai";
import { Icons } from '../utils/icons';

interface GeminiAnalysisProps {
  files: FileMetadata[];
  clusters: FileCluster[];
}

export const GeminiAnalysis: React.FC<GeminiAnalysisProps> = ({ files, clusters }) => {
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiKey, setApiKey] = useState<string>(""); 
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initialize with a system message about the current context
  useEffect(() => {
    if (files.length > 0 && messages.length === 0) {
        setMessages([{
            role: 'model',
            text: `I have analyzed ${files.length} files. The data is grouped into ${clusters.length} clusters based on size and timestamp anomalies. I can help identify suspicious files, outliers, or patterns in the EXIF metadata.`
        }]);
    }
  }, [files, clusters]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    // Use the provided key or env key
    const keyToUse = apiKey || process.env.API_KEY;
    
    if (!keyToUse) {
        setMessages(prev => [...prev, { role: 'user', text: input }, { role: 'model', text: 'Please enter a valid Gemini API Key to proceed.' }]);
        setInput('');
        return;
    }

    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: keyToUse });
      
      // Prepare Context with expanded metadata
      const topFiles = files.sort((a, b) => b.size - a.size).slice(0, 20);
      const fileSummary = topFiles.map(f => ({
          name: f.name,
          ext: f.extension,
          size: f.size,
          md5: f.md5,
          date: new Date(f.lastModified).toISOString(),
          exif: JSON.stringify(f.metadata).slice(0, 100) + "..."
      }));

      const context = `
        You are a Digital Forensics Expert Assistant (DFIR).
        Dataset: ${files.length} files.
        Clusters: ${clusters.length} groups based on Size vs Time.
        
        Sample Data (Top 20 Largest):
        ${JSON.stringify(fileSummary, null, 2)}
        
        User Query: ${userMsg}
        
        Provide a professional forensic assessment. If asked about clusters, explain that outliers often indicate manipulated timestamps or data exfiltration staging.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: context,
      });

      const text = response.text;
      setMessages(prev => [...prev, { role: 'model', text: text || "No response generated." }]);

    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: `Error: ${(error as Error).message}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-lg border border-slate-800 overflow-hidden">
      <div className="p-4 border-b border-slate-800 bg-slate-900/80 backdrop-blur flex justify-between items-center">
        <h2 className="font-semibold text-cyan-400 flex items-center gap-2">
            <Icons.BrainCircuit className="w-5 h-5" />
            AI Forensic Analyst
        </h2>
        {!process.env.API_KEY && (
             <input 
                type="password" 
                placeholder="Enter Gemini API Key" 
                className="bg-slate-950 border border-slate-700 rounded px-2 py-1 text-xs text-slate-300 w-48"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
             />
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-lg p-3 text-sm ${m.role === 'user' ? 'bg-cyan-900/40 text-cyan-100 border border-cyan-800' : 'bg-slate-800 text-slate-300 border border-slate-700'}`}>
                    <div className="whitespace-pre-wrap">{m.text}</div>
                </div>
            </div>
        ))}
        {loading && (
            <div className="flex justify-start">
                <div className="bg-slate-800 text-slate-400 p-3 rounded-lg text-xs animate-pulse">
                    Analyzing forensic artifacts...
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-slate-950 border-t border-slate-800">
        <div className="flex gap-2">
            <input
                type="text"
                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-200 focus:ring-1 focus:ring-cyan-500 outline-none"
                placeholder="Ask about suspicious files, MD5 matches, or anomalies..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button 
                onClick={handleSend}
                disabled={loading}
                className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
            >
                Send
            </button>
        </div>
      </div>
    </div>
  );
};