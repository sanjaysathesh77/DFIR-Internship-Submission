
import React from 'react';
import { FileMetadata, AppView } from '../types';
import { formatBytes } from '../utils/fileProcessor';
import { Icons } from '../utils/icons';

interface SidebarProps {
  files: FileMetadata[];
  currentView: AppView;
  onChangeView: (view: AppView) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ files, currentView, onChangeView }) => {
  const totalSize = files.reduce((acc, f) => acc + f.size, 0);
  
  const typeCounts = files.reduce((acc, f) => {
    acc[f.extension] = (acc[f.extension] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const sortedTypes = Object.entries(typeCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  return (
    <div className="w-64 bg-slate-900 border-r border-slate-800 h-screen flex flex-col fixed left-0 top-0 text-sm">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-xl font-bold text-cyan-400 flex items-center gap-2">
          <Icons.ShieldAlert className="w-6 h-6" />
          DFIR Meta
        </h1>
        <p className="text-slate-500 text-xs mt-1">Forensic Metadata Dashboard</p>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        <button 
          onClick={() => onChangeView(AppView.UPLOAD)}
          className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${currentView === AppView.UPLOAD ? 'bg-cyan-900/20 text-cyan-400' : 'text-slate-400 hover:bg-slate-800'}`}
        >
          <Icons.Upload className="w-5 h-5" />
          Import Data
        </button>
        <button 
           onClick={() => onChangeView(AppView.DASHBOARD)}
           disabled={files.length === 0}
           className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${currentView === AppView.DASHBOARD ? 'bg-cyan-900/20 text-cyan-400' : 'text-slate-400 hover:bg-slate-800'} ${files.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Icons.Table className="w-5 h-5" />
          File Explorer
        </button>
        <button 
           onClick={() => onChangeView(AppView.GROUPING)}
           disabled={files.length === 0}
           className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${currentView === AppView.GROUPING ? 'bg-cyan-900/20 text-cyan-400' : 'text-slate-400 hover:bg-slate-800'} ${files.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Icons.PieChart className="w-5 h-5" />
          Metadata Pivot
        </button>
        <button 
           onClick={() => onChangeView(AppView.COMPARE)}
           disabled={files.length === 0}
           className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${currentView === AppView.COMPARE ? 'bg-cyan-900/20 text-cyan-400' : 'text-slate-400 hover:bg-slate-800'} ${files.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <Icons.GitCompare className="w-5 h-5" />
          Hash Compare
        </button>
      </nav>

      {files.length > 0 && (
        <div className="p-4 bg-slate-950/50 border-t border-slate-800">
          <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Case Statistics</h3>
          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between">
              <span>Total Files</span>
              <span className="font-mono text-cyan-400">{files.length}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Size</span>
              <span className="font-mono text-cyan-400">{formatBytes(totalSize)}</span>
            </div>
          </div>
          
          <div className="mt-4">
             <h4 className="text-xs text-slate-600 mb-2">Top Extensions</h4>
             {sortedTypes.map(([ext, count]) => (
               <div key={ext} className="flex items-center justify-between text-xs text-slate-400 mb-1">
                 <span className="uppercase badge px-1.5 py-0.5 bg-slate-800 rounded">{ext}</span>
                 <span>{count}</span>
               </div>
             ))}
          </div>
        </div>
      )}
    </div>
  );
};