
import React, { useState, useMemo } from 'react';
import { FileMetadata } from '../types';
import { Icons } from '../utils/icons';
import { formatBytes } from '../utils/fileProcessor';

interface HashComparatorProps {
  files: FileMetadata[];
}

export const HashComparator: React.FC<HashComparatorProps> = ({ files }) => {
  const [mode, setMode] = useState<'duplicates' | 'manual'>('duplicates');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [hashFilter, setHashFilter] = useState('');

  // Group files by SHA256 to find duplicates
  const duplicateGroups = useMemo(() => {
    const groups: Record<string, FileMetadata[]> = {};
    files.forEach(f => {
      const hash = f.sha256 || f.sha1 || f.md5 || 'unknown';
      if (!groups[hash]) groups[hash] = [];
      groups[hash].push(f);
    });
    return Object.entries(groups)
        .filter(([_, group]) => group.length > 1)
        .sort((a, b) => b[1][0].size - a[1][0].size); // Sort by size descending
  }, [files]);

  // Filter files for manual list
  const filteredFiles = useMemo(() => {
    return files.filter(f => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearch = 
        f.name.toLowerCase().includes(searchLower) || 
        f.path.toLowerCase().includes(searchLower);
      
      const matchesHash = !hashFilter || 
        (f.md5?.toLowerCase() === hashFilter.toLowerCase()) ||
        (f.sha1.toLowerCase() === hashFilter.toLowerCase()) ||
        (f.sha256?.toLowerCase() === hashFilter.toLowerCase());

      return matchesSearch && matchesHash;
    });
  }, [files, searchTerm, hashFilter]);

  const toggleSelection = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedIds(newSet);
  };

  const selectedFilesList = useMemo(() => {
    return files.filter(f => selectedIds.has(f.id));
  }, [files, selectedIds]);

  // Comparison helpers
  const allMatch = (key: keyof FileMetadata | 'md5' | 'sha1' | 'sha256') => {
    if (selectedFilesList.length < 2) return true;
    const first = selectedFilesList[0][key];
    return selectedFilesList.every(f => f[key] === first);
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/50 rounded-lg border border-slate-800 overflow-hidden">
      {/* Header / Tab Bar */}
      <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900 p-2">
        <div className="flex gap-2">
          <button
            onClick={() => setMode('duplicates')}
            className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
              mode === 'duplicates' 
                ? 'bg-cyan-900/30 text-cyan-400 border border-cyan-900' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Icons.GitCompare className="w-4 h-4" />
            Duplicate Scanner
            <span className="bg-slate-800 px-2 py-0.5 rounded-full text-xs text-slate-400">
              {duplicateGroups.length} groups
            </span>
          </button>
          <button
            onClick={() => setMode('manual')}
            className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
              mode === 'manual' 
                ? 'bg-cyan-900/30 text-cyan-400 border border-cyan-900' 
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Icons.Table className="w-4 h-4" />
            Manual Comparison
            {selectedIds.size > 0 && (
               <span className="bg-cyan-600 text-white px-2 py-0.5 rounded-full text-xs">
                {selectedIds.size}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-hidden relative">
        
        {/* DUPLICATE VIEW */}
        {mode === 'duplicates' && (
          <div className="h-full overflow-y-auto p-6">
            {duplicateGroups.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500">
                <Icons.ShieldAlert className="w-12 h-12 mb-4 opacity-50" />
                <h3 className="text-lg font-semibold text-slate-300">No Duplicates Detected</h3>
                <p>All {files.length} files have unique cryptographic hashes.</p>
              </div>
            ) : (
              <div className="space-y-6 max-w-5xl mx-auto">
                <div className="bg-amber-900/20 border border-amber-900/50 p-4 rounded-lg flex items-start gap-3">
                  <Icons.ShieldAlert className="w-5 h-5 text-amber-500 mt-0.5" />
                  <div>
                    <h3 className="text-amber-400 font-semibold text-sm">Duplicate Warning</h3>
                    <p className="text-amber-200/70 text-xs mt-1">
                      Files grouped below share identical contents (SHA-256 hash match). 
                      Metadata like filenames and timestamps may differ, indicating copying, renaming, or tampering.
                    </p>
                  </div>
                </div>

                {duplicateGroups.map(([hash, groupFiles], idx) => (
                  <div key={hash} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                    <div className="bg-slate-950/50 p-3 border-b border-slate-800 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                         <span className="bg-red-900/30 text-red-400 text-xs font-mono px-2 py-1 rounded border border-red-900/50">
                           Group #{idx + 1}
                         </span>
                         <span className="text-slate-500 text-xs font-mono truncate max-w-[200px] sm:max-w-md" title={hash}>
                           SHA256: {hash}
                         </span>
                      </div>
                      <div className="text-xs text-slate-400">
                        {formatBytes(groupFiles[0].size)}
                      </div>
                    </div>
                    <div className="divide-y divide-slate-800/50">
                      {groupFiles.map(f => (
                        <div key={f.id} className="p-3 hover:bg-slate-800/30 flex items-center justify-between group">
                          <div className="flex items-center gap-3 overflow-hidden">
                             <Icons.FileText className="w-4 h-4 text-slate-600 flex-shrink-0" />
                             <div className="min-w-0">
                               <div className="text-sm text-slate-200 truncate" title={f.name}>{f.name}</div>
                               <div className="text-xs text-slate-500 truncate" title={f.path}>{f.path}</div>
                             </div>
                          </div>
                          <div className="text-xs text-slate-500 whitespace-nowrap pl-4">
                            {new Date(f.lastModified).toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* MANUAL VIEW */}
        {mode === 'manual' && (
          <div className="flex h-full">
            {/* Left Sidebar: File Selector */}
            <div className="w-80 border-r border-slate-800 bg-slate-950 flex flex-col">
              <div className="p-4 border-b border-slate-800 space-y-2">
                <input 
                  type="text" 
                  placeholder="Search filename..." 
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-sm text-slate-200 focus:ring-1 focus:ring-cyan-500 outline-none"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
                <input 
                  type="text" 
                  placeholder="Paste Hash to Filter..." 
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-xs font-mono text-slate-200 focus:ring-1 focus:ring-cyan-500 outline-none"
                  value={hashFilter}
                  onChange={e => setHashFilter(e.target.value.trim())}
                />
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {filteredFiles.length === 0 && (
                  <div className="text-center p-4 text-xs text-slate-500">No files found matching filters.</div>
                )}
                {filteredFiles.map(f => (
                  <div 
                    key={f.id} 
                    onClick={() => toggleSelection(f.id)}
                    className={`p-2 rounded cursor-pointer flex items-start gap-3 border transition-colors ${
                      selectedIds.has(f.id) 
                        ? 'bg-cyan-900/20 border-cyan-700' 
                        : 'bg-transparent border-transparent hover:bg-slate-800'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded border mt-1 flex items-center justify-center flex-shrink-0 ${
                      selectedIds.has(f.id) ? 'bg-cyan-600 border-cyan-600' : 'border-slate-600'
                    }`}>
                      {selectedIds.has(f.id) && <Icons.X className="w-3 h-3 text-white rotate-45" />}
                    </div>
                    <div className="overflow-hidden">
                      <div className="text-sm text-slate-200 truncate" title={f.name}>{f.name}</div>
                      <div className="text-xs text-slate-500 truncate">{f.path}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Content: Comparison Table */}
            <div className="flex-1 overflow-auto bg-slate-900 p-6">
              {selectedFilesList.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-500 opacity-50">
                   <Icons.GitCompare className="w-16 h-16 mb-4" />
                   <p>Select files from the left to compare metadata & hashes.</p>
                </div>
              ) : (
                <div className="min-w-max">
                   <table className="w-full border-collapse">
                     <thead>
                       <tr>
                         <th className="p-3 text-left text-sm font-semibold text-slate-500 border-b border-slate-700 bg-slate-900 sticky left-0 z-10 w-48">Property</th>
                         {selectedFilesList.map(f => (
                           <th key={f.id} className="p-3 text-left text-sm font-semibold text-cyan-400 border-b border-slate-700 min-w-[200px] max-w-[300px]">
                             <div className="truncate" title={f.name}>{f.name}</div>
                           </th>
                         ))}
                       </tr>
                     </thead>
                     <tbody className="text-sm">
                       {/* Standard Fields */}
                       <tr className="group hover:bg-slate-800/30">
                         <td className="p-3 text-slate-400 font-medium border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30">Size</td>
                         {selectedFilesList.map(f => (
                           <td key={f.id} className={`p-3 border-b border-slate-800 font-mono ${allMatch('size') ? 'text-green-400' : 'text-slate-300'}`}>
                             {formatBytes(f.size)}
                           </td>
                         ))}
                       </tr>
                       <tr className="group hover:bg-slate-800/30">
                         <td className="p-3 text-slate-400 font-medium border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30">MD5</td>
                         {selectedFilesList.map(f => (
                           <td key={f.id} className={`p-3 border-b border-slate-800 font-mono text-xs break-all ${allMatch('md5') ? 'text-green-400 bg-green-900/10' : 'text-red-300'}`}>
                             {f.md5 || '-'}
                           </td>
                         ))}
                       </tr>
                       <tr className="group hover:bg-slate-800/30">
                         <td className="p-3 text-slate-400 font-medium border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30">SHA-1</td>
                         {selectedFilesList.map(f => (
                           <td key={f.id} className={`p-3 border-b border-slate-800 font-mono text-xs break-all ${allMatch('sha1') ? 'text-green-400 bg-green-900/10' : 'text-red-300'}`}>
                             {f.sha1}
                           </td>
                         ))}
                       </tr>
                       <tr className="group hover:bg-slate-800/30">
                         <td className="p-3 text-slate-400 font-medium border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30">SHA-256</td>
                         {selectedFilesList.map(f => (
                           <td key={f.id} className={`p-3 border-b border-slate-800 font-mono text-[10px] break-all ${allMatch('sha256') ? 'text-green-400 bg-green-900/10' : 'text-red-300'}`}>
                             {f.sha256 || '-'}
                           </td>
                         ))}
                       </tr>
                       <tr className="group hover:bg-slate-800/30">
                         <td className="p-3 text-slate-400 font-medium border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30">Modified Date</td>
                         {selectedFilesList.map(f => (
                           <td key={f.id} className="p-3 border-b border-slate-800 text-slate-300">
                             {new Date(f.lastModified).toLocaleString()}
                           </td>
                         ))}
                       </tr>
                       {/* Add a spacer row */}
                       <tr><td className="p-2 bg-slate-950 text-xs text-slate-500 font-bold sticky left-0" colSpan={selectedFilesList.length + 1}>EXTRACTED METADATA</td></tr>
                       
                       {/* Dynamic Metadata Intersection */}
                       {Array.from(new Set(selectedFilesList.flatMap(f => Object.keys(f.metadata)))).sort().map(key => {
                          // check if all values for this key match
                          const values = selectedFilesList.map(f => String(f.metadata[key] || ''));
                          const allValuesMatch = values.every(v => v === values[0] && v !== '');
                          
                          return (
                            <tr key={key} className="group hover:bg-slate-800/30">
                                <td className="p-3 text-slate-500 text-xs font-mono border-b border-slate-800 sticky left-0 bg-slate-900 group-hover:bg-slate-800/30 truncate max-w-[200px]" title={key}>
                                    {key}
                                </td>
                                {selectedFilesList.map(f => (
                                    <td key={f.id} className={`p-3 border-b border-slate-800 text-xs font-mono ${allValuesMatch ? 'text-slate-400' : 'text-amber-200'}`}>
                                        {String(f.metadata[key] || '-')}
                                    </td>
                                ))}
                            </tr>
                          );
                       })}
                     </tbody>
                   </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
