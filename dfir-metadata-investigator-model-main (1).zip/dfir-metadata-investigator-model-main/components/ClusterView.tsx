import React from 'react';
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, ZAxis, Tooltip, Cell, Legend } from 'recharts';
import { FileMetadata, FileCluster } from '../types';
import { formatBytes } from '../utils/fileProcessor';

interface ClusterViewProps {
  files: FileMetadata[];
  clusters: FileCluster[];
}

export const ClusterView: React.FC<ClusterViewProps> = ({ files }) => {
  // Transform data for Recharts
  // X: Time (normalized roughly for display)
  // Y: Size (Log scale roughly)
  // We use the raw values but format axes
  
  const data = files.map(f => ({
    ...f,
    x: f.lastModified,
    y: f.size,
    z: 1 // Bubble size constant
  }));

  const COLORS = ['#3b82f6', '#a855f7', '#22c55e', '#f97316', '#ef4444'];

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded shadow-xl text-xs">
          <p className="font-bold text-cyan-400 mb-1">{data.name}</p>
          <p className="text-slate-300">Size: {formatBytes(data.size)}</p>
          <p className="text-slate-300">Date: {new Date(data.lastModified).toLocaleDateString()}</p>
          <p className="text-slate-400 mt-1">Cluster: {data.clusterId !== undefined ? data.clusterId + 1 : 'N/A'}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="h-full flex flex-col">
      <div className="mb-4 bg-slate-900/50 p-4 rounded-lg border border-slate-800">
        <h3 className="text-lg font-medium text-slate-200">Metadata Clusters (K-Means)</h3>
        <p className="text-sm text-slate-500">
            Grouping files based on <strong>File Size (Log)</strong> vs <strong>Modification Time</strong>. 
            Outliers or isolated small clusters often indicate suspicious drops or anomalies.
        </p>
      </div>

      <div className="flex-1 bg-slate-900 rounded-lg border border-slate-800 p-4 relative">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
            <XAxis 
                type="number" 
                dataKey="x" 
                name="Time" 
                domain={['auto', 'auto']}
                tickFormatter={(unixTime) => new Date(unixTime).toLocaleDateString()} 
                stroke="#64748b"
                tick={{fontSize: 10}}
            />
            <YAxis 
                type="number" 
                dataKey="y" 
                name="Size" 
                domain={['auto', 'auto']} // Log scale visual simulation
                tickFormatter={(size) => formatBytes(size, 0)} 
                stroke="#64748b"
                tick={{fontSize: 10}}
            />
            <ZAxis type="number" dataKey="z" range={[20, 20]} />
            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
            <Legend />
            <Scatter name="Files" data={data} fill="#8884d8">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[(entry.clusterId || 0) % COLORS.length]} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
        
        {/* Legend Overlay */}
        <div className="absolute top-4 right-4 bg-slate-950/80 p-2 rounded border border-slate-800 text-xs">
            {COLORS.slice(0, 4).map((color, i) => (
                <div key={i} className="flex items-center gap-2 mb-1">
                    <div className="w-3 h-3 rounded-full" style={{background: color}}></div>
                    <span className="text-slate-400">Cluster {i+1}</span>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};
