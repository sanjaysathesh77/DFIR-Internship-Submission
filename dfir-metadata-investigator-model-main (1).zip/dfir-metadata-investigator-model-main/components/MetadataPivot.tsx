
import React, { useState, useMemo } from 'react';
import { FileMetadata } from '../types';
import { formatBytes } from '../utils/fileProcessor';
import { Icons } from '../utils/icons';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface MetadataPivotProps {
  files: FileMetadata[];
}

type GroupByOption = 'extension' | 'type' | 'cameraMake' | 'cameraModel' | 'author' | 'software' | 'dateModified';

export const MetadataPivot: React.FC<MetadataPivotProps> = ({ files }) => {
  const [groupBy, setGroupBy] = useState<GroupByOption>('extension');
  const [selectedGroupKey, setSelectedGroupKey] = useState<string | null>(null);

  // Aggregate Data
  const groups = useMemo(() => {
    const map = new Map<string, { count: number; size: number; files: FileMetadata[] }>();

    files.forEach(f => {
      let key = 'Unknown';
      
      switch (groupBy) {
        case 'extension':
          key = f.extension || 'None';
          break;
        case 'type':
          key = f.type;
          break;
        case 'cameraMake':
          key = String(f.metadata['EXIF:Make'] || 'N/A');
          break;
        case 'cameraModel':
          key = String(f.metadata['EXIF:Model'] || 'N/A');
          break;
        case 'author':
          key = String(f.metadata['PDF:Author'] || f.metadata['Office:LastModifiedBy'] || 'N/A');
          break;
        case 'software':
          key = String(f.metadata['EXIF:Software'] || f.metadata['PDF:Producer'] || 'N/A');
          break;
        case 'dateModified':
          key = new Date(f.lastModified).toISOString().split('T')[0];
          break;
      }

      if (!map.has(key)) {
        map.set(key, { count: 0, size: 0, files: [] });
      }
      const entry = map.get(key)!;
      entry.count++;
      entry.size += f.size;
      entry.files.push(f);
    });

    // Convert map to array and sort by count descending
    return Array.from(map.entries())
      .map(([key, data]) => ({ key, ...data }))
      .sort((a, b) => b.count - a.count);

  }, [files, groupBy]);

  const chartData = groups.slice(0, 15).map(g => ({
    name: g.key,
    count: g.count,
    size: g.size
  }));

  const selectedGroupData = selectedGroupKey ? groups.find(g => g.key === selectedGroupKey) : null;

  const COLORS = ['#0ea5e9', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#6366f1', '#ec4899', '#84cc16'];

  return (
    <div className="flex flex-col h-full space-y-4">
      
      {/* Toolbar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-cyan-900/20 text-cyan-400 rounded-lg">
            <Icons.PieChart className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-slate-200">Metadata Pivot</h2>
            <p className="text-sm text-slate-500">Aggregated forensic breakdown of evidence</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-400 font-medium">Group By:</span>
          <select 
            value={groupBy} 
            onChange={(e) => { setGroupBy(e.target.value as GroupByOption); setSelectedGroupKey(null); }}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block p-2.5"
          >
            <option value="extension">File Extension</option>
            <option value="type">MIME Type</option>
            <option value="dateModified">Date Modified (Day)</option>
            <option value="cameraMake">Camera Make (EXIF)</option>
            <option value="cameraModel">Camera Model (EXIF)</option>
            <option value="author">Author / User</option>
            <option value="software">Software / Producer</option>
          </select>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Left Col: Visualization & Aggregation Table */}
        <div className="flex flex-col gap-4 h-full min-h-0">
            
            {/* Chart */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 h-1/3 min-h-[200px]">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Distribution ({groupBy})</h3>
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                        <XAxis dataKey="name" stroke="#64748b" tick={{fontSize: 10}} interval={0} angle={-45} textAnchor="end" height={50} />
                        <YAxis stroke="#64748b" tick={{fontSize: 10}} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#e2e8f0' }}
                            cursor={{fill: '#1e293b'}}
                        />
                        <Bar dataKey="count" name="File Count" radius={[4, 4, 0, 0]} onClick={(data) => setSelectedGroupKey(data.name)}>
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} cursor="pointer" />
                          ))}
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
            </div>

            {/* Group Table */}
            <div className="flex-1 bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col min-h-0">
                <div className="p-3 border-b border-slate-800 bg-slate-900/50">
                    <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Group Statistics</h3>
                </div>
                <div className="flex-1 overflow-y-auto">
                    <table className="w-full text-sm text-left text-slate-400">
                        <thead className="text-xs text-slate-500 uppercase bg-slate-950 sticky top-0">
                            <tr>
                                <th className="px-4 py-2">Group Key</th>
                                <th className="px-4 py-2 text-right">Count</th>
                                <th className="px-4 py-2 text-right">Total Size</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                            {groups.map((group) => (
                                <tr 
                                    key={group.key} 
                                    onClick={() => setSelectedGroupKey(group.key)}
                                    className={`cursor-pointer hover:bg-slate-800/50 transition-colors ${selectedGroupKey === group.key ? 'bg-cyan-900/20' : ''}`}
                                >
                                    <td className="px-4 py-2 font-medium text-slate-300 truncate max-w-[200px]" title={group.key}>
                                        {group.key}
                                    </td>
                                    <td className="px-4 py-2 text-right font-mono text-cyan-400">{group.count}</td>
                                    <td className="px-4 py-2 text-right font-mono text-slate-500">{formatBytes(group.size)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        {/* Right Col: Detailed File List for Selected Group */}
        <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden flex flex-col h-full min-h-0">
            {selectedGroupData ? (
                <>
                    <div className="p-4 border-b border-slate-800 bg-slate-950 flex justify-between items-center">
                        <div>
                            <h3 className="font-bold text-cyan-400">{selectedGroupData.key}</h3>
                            <p className="text-xs text-slate-500 mt-1">
                                {selectedGroupData.count} files • {formatBytes(selectedGroupData.size)}
                            </p>
                        </div>
                        <button 
                            onClick={() => setSelectedGroupKey(null)}
                            className="text-slate-500 hover:text-white"
                        >
                            <Icons.X className="w-5 h-5" />
                        </button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-0">
                        <table className="w-full text-sm text-left text-slate-400">
                            <thead className="text-xs text-slate-500 uppercase bg-slate-950 sticky top-0">
                                <tr>
                                    <th className="px-4 py-3">Filename</th>
                                    <th className="px-4 py-3 text-right">Size</th>
                                    <th className="px-4 py-3">Modified</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/50">
                                {selectedGroupData.files.map((file) => (
                                    <tr key={file.id} className="hover:bg-slate-800/30 group">
                                        <td className="px-4 py-2">
                                            <div className="text-slate-300 truncate max-w-[250px]" title={file.name}>{file.name}</div>
                                            <div className="text-xs text-slate-600 truncate max-w-[250px]">{file.path}</div>
                                        </td>
                                        <td className="px-4 py-2 text-right font-mono text-xs">{formatBytes(file.size)}</td>
                                        <td className="px-4 py-2 text-xs whitespace-nowrap">{new Date(file.lastModified).toLocaleDateString()}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </>
            ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-500 p-8 text-center">
                    <Icons.Table className="w-12 h-12 mb-4 opacity-30" />
                    <h3 className="text-lg font-medium text-slate-400">Select a Group</h3>
                    <p className="text-sm mt-2 max-w-xs">Click on a bar in the chart or a row in the table to view the specific files belonging to that metadata group.</p>
                </div>
            )}
        </div>

      </div>
    </div>
  );
};
