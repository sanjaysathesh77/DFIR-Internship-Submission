import streamlit as st
import pandas as pd
import json
import io
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
import hashlib
import os
from datetime import datetime
import tempfile
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import plotly.express as px
import plotly.graph_objects as go
from collections import defaultdict
import random

try:
    import exifread
    EXIFREAD_AVAILABLE = True
except ImportError:
    EXIFREAD_AVAILABLE = False
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
try:
    import PyPDF2
    PYPDF2_AVAILABLE = True
except ImportError:
    PYPDF2_AVAILABLE = False

@dataclass
class FileMetadata:
    id: str
    name: str
    path: str
    size: int
    type: str
    extension: str
    last_modified: float
    sha1: str
    sha256: str
    md5: str
    cluster_id: Optional[int] = None
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}

def calculate_hashes(file_bytes: bytes) -> tuple[str, str, str]:
    sha1 = hashlib.sha1(file_bytes).hexdigest()
    sha256 = hashlib.sha256(file_bytes).hexdigest()
    md5 = hashlib.md5(file_bytes).hexdigest()
    return sha1, sha256, md5

def extract_metadata(file_bytes: bytes, filename: str, extension: str) -> Dict[str, Any]:
    metadata = {'System:FileSize': len(file_bytes), 'System:FileName': filename}
    
    try:
        if extension.lower() in ['jpg', 'jpeg', 'png', 'tiff', 'bmp'] and PIL_AVAILABLE:
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(file_bytes)
                tmp.flush()
                img = Image.open(tmp.name)
                metadata.update({
                    'ImageWidth': img.width,
                    'ImageHeight': img.height,
                    'ColorMode': img.mode,
                    'Format': img.format
                })
                img.close()
                os.unlink(tmp.name)
                
        if extension.lower() in ['jpg', 'jpeg', 'tiff'] and EXIFREAD_AVAILABLE:
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(file_bytes)
                tmp.flush()
                with open(tmp.name, 'rb') as f:
                    tags = exifread.process_file(f)
                    for tag in tags:
                        if tag not in ['JPEGThumbnail', 'TIFFThumbnail']:
                            metadata[f'EXIF:{tag}'] = str(tags[tag])
                os.unlink(tmp.name)
                
        elif extension.lower() == 'pdf' and PYPDF2_AVAILABLE:
            reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
            if reader.metadata:
                metadata.update({
                    'PDF:Pages': len(reader.pages),
                    'PDF:Title': reader.metadata.title,
                    'PDF:Author': reader.metadata.author,
                    'PDF:Creator': reader.metadata.creator,
                    'PDF:Producer': reader.metadata.producer,
                    'PDF:Subject': reader.metadata.subject
                })
                
        # Simulate realistic metadata for demo
        if extension.lower() in ['jpg', 'jpeg', 'png', 'webp', 'heic']:
            makes = ['Canon', 'Nikon', 'Sony', 'Apple']
            make = random.choice(makes)
            metadata.update({
                'EXIF:Make': make,
                'EXIF:Model': 'iPhone 13 Pro' if make == 'Apple' else 'EOS R5',
                'EXIF:Software': random.choice(['Adobe Photoshop 2023', 'Ver.1.0.2']),
                'EXIF:ISO': random.choice([100, 200, 400, 800, 1600]),
                'EXIF:ColorSpace': 'sRGB'
            })
            
    except Exception as e:
        metadata['Error'] = str(e)
    return metadata

def process_file(uploaded_file) -> FileMetadata:
    try:
        file_bytes = uploaded_file.read()
        sha1, sha256, md5 = calculate_hashes(file_bytes)
        extension = uploaded_file.name.split('.')[-1].lower() if '.' in uploaded_file.name else 'unknown'
        metadata = extract_metadata(file_bytes, uploaded_file.name, extension)
        
        return FileMetadata(
            id=str(hash(uploaded_file.name + str(len(file_bytes)))),
            name=uploaded_file.name or 'unknown_file',
            path=uploaded_file.name or 'unknown_path',
            size=len(file_bytes),
            type=uploaded_file.type or 'application/octet-stream',
            extension=extension,
            last_modified=datetime.now().timestamp(),
            sha1=sha1,
            sha256=sha256,
            md5=md5,
            metadata=metadata or {}
        )
    except Exception as e:
        # Return a minimal FileMetadata object for failed processing
        return FileMetadata(
            id=str(hash(str(uploaded_file.name) + str(datetime.now().timestamp()))),
            name=getattr(uploaded_file, 'name', 'error_file'),
            path=getattr(uploaded_file, 'name', 'error_path'),
            size=0,
            type='error',
            extension='error',
            last_modified=datetime.now().timestamp(),
            sha1='error',
            sha256='error',
            md5='error',
            metadata={'error': str(e)}
        )

def perform_clustering(files: List[FileMetadata], k: int = 4) -> List[FileMetadata]:
    if len(files) < k:
        for i, f in enumerate(files):
            f.cluster_id = i
        return files
        
    sizes = [f.size for f in files]
    times = [f.last_modified for f in files]
    scaler = StandardScaler()
    features = scaler.fit_transform(list(zip(sizes, times)))
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(features)
    
    for i, f in enumerate(files):
        f.cluster_id = labels[i]
    return files

def format_bytes(size: int) -> str:
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} TB"

def render_upload_view():
    st.markdown("### 📁 Evidence Ingestion")
    st.markdown("Upload files to begin forensic analysis. System will extract metadata, compute hashes, and cluster files.")
    
    uploaded_files = st.file_uploader("Select Evidence Files", accept_multiple_files=True, type=None)
    
    if uploaded_files and st.button("🔍 Process Files", type="primary"):
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        files = []
        for i, uploaded_file in enumerate(uploaded_files):
            status_text.text(f'Processing {uploaded_file.name}...')
            files.append(process_file(uploaded_file))
            progress_bar.progress((i + 1) / len(uploaded_files))
        
        status_text.text('Performing clustering analysis...')
        files = perform_clustering(files)
        
        st.session_state.files = files
        st.session_state.processed = True
        
        progress_bar.progress(1.0)
        status_text.text('✅ Processing complete!')
        st.success(f"Successfully processed {len(files)} files!")
        st.rerun()

def render_dashboard():
    files = st.session_state.files
    st.markdown("### 📊 File Explorer")
    
    if not files:
        st.info("No files to display. Please upload files first.")
        return
    
    # Search and filters
    col1, col2 = st.columns([3, 1])
    with col1:
        search = st.text_input("🔍 Search files (name, extension, hash)")
    with col2:
        sort_by = st.selectbox("Sort by", ["name", "size", "extension", "last_modified"])
    
    # Filter files with error handling
    filtered_files = []
    try:
        for f in files:
            if search:
                search_lower = search.lower()
                if (search_lower in getattr(f, 'name', '').lower() or 
                    search_lower in getattr(f, 'extension', '').lower() or 
                    search_lower in getattr(f, 'md5', '').lower() or 
                    search_lower in getattr(f, 'sha1', '').lower()):
                    filtered_files.append(f)
            else:
                filtered_files.append(f)
    except Exception as e:
        st.error(f"Error filtering files: {str(e)}")
        filtered_files = files
    
    # Sort files with error handling
    try:
        filtered_files.sort(key=lambda x: getattr(x, sort_by, ''), reverse=(sort_by == "size"))
    except Exception as e:
        st.warning(f"Error sorting files: {str(e)}")
    
    # Display table
    if filtered_files:
        df_data = []
        for f in filtered_files:
            try:
                df_data.append({
                    "Name": str(getattr(f, 'name', 'Unknown'))[:50],
                    "Size": format_bytes(getattr(f, 'size', 0)),
                    "Extension": str(getattr(f, 'extension', 'unknown')).upper(),
                    "Modified": datetime.fromtimestamp(getattr(f, 'last_modified', 0)).strftime("%Y-%m-%d %H:%M"),
                    "MD5": (getattr(f, 'md5', 'N/A')[:16] + "...") if getattr(f, 'md5', None) else "N/A",
                    "SHA1": (getattr(f, 'sha1', 'N/A')[:16] + "...") if getattr(f, 'sha1', None) else "N/A"
                })
            except Exception as e:
                st.warning(f"Error processing file {getattr(f, 'name', 'Unknown')}: {str(e)}")
        
        if df_data:
            df = pd.DataFrame(df_data)
            st.dataframe(df, use_container_width=True)
            
            # File details
            st.markdown("#### 🔍 File Details")
            file_names = [getattr(f, 'name', f'File_{i}') for i, f in enumerate(filtered_files)]
            selected_name = st.selectbox("Select file for detailed view", file_names)
            
            if selected_name:
                try:
                    selected_file = next(f for f in filtered_files if getattr(f, 'name', '') == selected_name)
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown("**File Information**")
                        st.write(f"**Name:** {getattr(selected_file, 'name', 'Unknown')}")
                        st.write(f"**Size:** {format_bytes(getattr(selected_file, 'size', 0))}")
                        st.write(f"**Type:** {getattr(selected_file, 'type', 'Unknown')}")
                        st.write(f"**Extension:** {getattr(selected_file, 'extension', 'unknown')}")
                        
                        st.markdown("**Cryptographic Hashes**")
                        st.code(f"MD5:    {getattr(selected_file, 'md5', 'N/A')}")
                        st.code(f"SHA1:   {getattr(selected_file, 'sha1', 'N/A')}")
                        st.code(f"SHA256: {getattr(selected_file, 'sha256', 'N/A')}")
                    
                    with col2:
                        st.markdown("**Extracted Metadata**")
                        metadata = getattr(selected_file, 'metadata', None)
                        if metadata:
                            st.json(metadata)
                        else:
                            st.info("No metadata extracted")
                except Exception as e:
                    st.error(f"Error displaying file details: {str(e)}")
            
            # Export with error handling
            try:
                export_data = []
                for f in filtered_files:
                    try:
                        export_data.append(asdict(f))
                    except Exception:
                        # Fallback for objects that can't be converted with asdict
                        export_data.append({
                            'name': getattr(f, 'name', 'Unknown'),
                            'size': getattr(f, 'size', 0),
                            'extension': getattr(f, 'extension', 'unknown'),
                            'md5': getattr(f, 'md5', 'N/A'),
                            'sha1': getattr(f, 'sha1', 'N/A'),
                            'sha256': getattr(f, 'sha256', 'N/A')
                        })
                
                if export_data:
                    csv_data = pd.DataFrame(export_data).to_csv(index=False)
                    st.download_button("📥 Export CSV", csv_data, "dfir_export.csv", "text/csv")
            except Exception as e:
                st.warning(f"Export functionality temporarily unavailable: {str(e)}")
        else:
            st.warning("No valid file data to display.")
    else:
        st.info("No files match your search criteria")

def render_grouping():
    files = st.session_state.files
    st.markdown("### 📈 Metadata Pivot Analysis")
    
    if not files:
        st.info("No files to analyze. Please upload files first.")
        return
    
    group_options = {
        "extension": "File Extension",
        "type": "MIME Type", 
        "cluster_id": "Cluster ID",
        "camera_make": "Camera Make (EXIF)",
        "software": "Software/Producer"
    }
    
    group_by = st.selectbox("Group files by", list(group_options.keys()), 
                           format_func=lambda x: group_options[x])
    
    # Group files with error handling
    groups = defaultdict(list)
    try:
        for f in files:
            key = "Unknown"
            try:
                if group_by == "extension":
                    key = (f.extension or "unknown").strip() or "unknown"
                elif group_by == "type":
                    key = (f.type or "unknown").strip() or "unknown"
                elif group_by == "cluster_id":
                    if f.cluster_id is not None:
                        key = f"Cluster {f.cluster_id + 1}"
                    else:
                        key = "Unassigned"
                elif group_by == "camera_make":
                    if hasattr(f, 'metadata') and f.metadata:
                        key = str(f.metadata.get("EXIF:Make", "Unknown")).strip() or "Unknown"
                    else:
                        key = "Unknown"
                elif group_by == "software":
                    if hasattr(f, 'metadata') and f.metadata:
                        software = f.metadata.get("EXIF:Software") or f.metadata.get("PDF:Producer")
                        key = str(software).strip() if software else "Unknown"
                    else:
                        key = "Unknown"
            except Exception as e:
                st.warning(f"Error processing file {f.name}: {str(e)}")
                key = "Error"
            
            groups[key].append(f)
    except Exception as e:
        st.error(f"Error during grouping: {str(e)}")
        return
    
    if not groups:
        st.warning("No groups created. Check your data.")
        return
    
    # Create visualization with error handling
    try:
        chart_data = []
        for group_name, group_files in groups.items():
            if group_files:  # Ensure group has files
                chart_data.append({
                    "Group": str(group_name)[:50],  # Truncate long names
                    "Count": len(group_files),
                    "Total Size": sum(getattr(f, 'size', 0) for f in group_files)
                })
        
        if not chart_data:
            st.warning("No data available for visualization.")
            return
            
        chart_df = pd.DataFrame(chart_data).sort_values("Count", ascending=False)
        
        col1, col2 = st.columns(2)
        with col1:
            if len(chart_df) > 0:
                fig = px.bar(chart_df, x="Group", y="Count", 
                           title=f"File Distribution by {group_options[group_by]}")
                fig.update_xaxis(tickangle=45)
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            if len(chart_df) > 0:
                fig2 = px.pie(chart_df, values="Count", names="Group", 
                            title="Distribution Breakdown")
                st.plotly_chart(fig2, use_container_width=True)
        
        # Group details table
        st.markdown("#### Group Statistics")
        if len(chart_df) > 0:
            display_df = chart_df.copy()
            display_df["Total Size"] = display_df["Total Size"].apply(format_bytes)
            st.dataframe(display_df, use_container_width=True)
        
        # Detailed view for selected group
        if groups:
            group_keys = list(groups.keys())
            selected_group = st.selectbox("Select group for detailed view", group_keys)
            
            if selected_group and selected_group in groups:
                st.markdown(f"#### Files in '{selected_group}'")
                group_files = groups[selected_group]
                
                if group_files:
                    group_df_data = []
                    for f in group_files:
                        try:
                            group_df_data.append({
                                "Name": str(f.name)[:50],  # Truncate long names
                                "Size": format_bytes(getattr(f, 'size', 0)),
                                "Modified": datetime.fromtimestamp(getattr(f, 'last_modified', 0)).strftime("%Y-%m-%d %H:%M"),
                                "MD5": (getattr(f, 'md5', 'N/A')[:16] + "...") if getattr(f, 'md5', None) else "N/A"
                            })
                        except Exception as e:
                            st.warning(f"Error processing file {getattr(f, 'name', 'Unknown')}: {str(e)}")
                    
                    if group_df_data:
                        group_df = pd.DataFrame(group_df_data)
                        st.dataframe(group_df, use_container_width=True)
                    else:
                        st.info("No valid files in this group.")
                else:
                    st.info("No files in selected group.")
                    
    except Exception as e:
        st.error(f"Error creating visualization: {str(e)}")
        st.info("Try selecting a different grouping option.")

def render_comparison():
    files = st.session_state.files
    st.markdown("### 🔍 Hash Comparison & Duplicate Detection")
    
    if not files:
        st.info("No files to compare. Please upload files first.")
        return
    
    tab1, tab2 = st.tabs(["🚨 Duplicate Scanner", "⚖️ Manual Comparison"])
    
    with tab1:
        st.markdown("#### Duplicate File Detection")
        
        try:
            # Find duplicates by SHA256 with error handling
            hash_groups = defaultdict(list)
            for f in files:
                sha256 = getattr(f, 'sha256', None)
                if sha256:
                    hash_groups[sha256].append(f)
            
            duplicates = {k: v for k, v in hash_groups.items() if len(v) > 1}
            
            if duplicates:
                st.warning(f"⚠️ Found {len(duplicates)} groups of duplicate files!")
                
                for i, (hash_val, duplicate_files) in enumerate(duplicates.items(), 1):
                    try:
                        file_size = getattr(duplicate_files[0], 'size', 0)
                        with st.expander(f"Duplicate Group #{i} - {len(duplicate_files)} files ({format_bytes(file_size)})"):
                            st.code(f"SHA256: {hash_val}")
                            
                            dup_data = []
                            for f in duplicate_files:
                                try:
                                    dup_data.append({
                                        "Name": str(getattr(f, 'name', 'Unknown'))[:50],
                                        "Path": str(getattr(f, 'path', 'Unknown'))[:50],
                                        "Size": format_bytes(getattr(f, 'size', 0)),
                                        "Modified": datetime.fromtimestamp(getattr(f, 'last_modified', 0)).strftime("%Y-%m-%d %H:%M")
                                    })
                                except Exception as e:
                                    st.warning(f"Error processing duplicate file: {str(e)}")
                            
                            if dup_data:
                                dup_df = pd.DataFrame(dup_data)
                                st.dataframe(dup_df, use_container_width=True)
                    except Exception as e:
                        st.error(f"Error displaying duplicate group {i}: {str(e)}")
            else:
                st.success("✅ No duplicate files detected. All files have unique SHA256 hashes.")
        except Exception as e:
            st.error(f"Error during duplicate detection: {str(e)}")
    
    with tab2:
        st.markdown("#### Manual File Comparison")
        
        try:
            file_names = [getattr(f, 'name', f'File_{i}') for i, f in enumerate(files)]
            selected_files = st.multiselect(
                "Select files to compare (2-10 files recommended)",
                file_names,
                max_selections=10
            )
            
            if len(selected_files) >= 2:
                try:
                    compare_files = [f for f in files if getattr(f, 'name', '') in selected_files]
                    
                    if compare_files:
                        # Comparison table
                        comparison_data = []
                        properties = ["Name", "Size", "Extension", "Type", "MD5", "SHA1", "SHA256"]
                        
                        for prop in properties:
                            row = {"Property": prop}
                            for f in compare_files:
                                try:
                                    fname = getattr(f, 'name', 'Unknown')[:20]
                                    if prop == "Name":
                                        row[fname] = getattr(f, 'name', 'Unknown')
                                    elif prop == "Size":
                                        row[fname] = format_bytes(getattr(f, 'size', 0))
                                    elif prop == "Extension":
                                        row[fname] = getattr(f, 'extension', 'unknown')
                                    elif prop == "Type":
                                        row[fname] = getattr(f, 'type', 'unknown')
                                    elif prop == "MD5":
                                        row[fname] = getattr(f, 'md5', 'N/A')
                                    elif prop == "SHA1":
                                        row[fname] = getattr(f, 'sha1', 'N/A')
                                    elif prop == "SHA256":
                                        row[fname] = getattr(f, 'sha256', 'N/A')
                                except Exception as e:
                                    row[f'File_{prop}'] = f"Error: {str(e)}"
                            comparison_data.append(row)
                        
                        if comparison_data:
                            comparison_df = pd.DataFrame(comparison_data)
                            st.dataframe(comparison_df, use_container_width=True)
                            
                            # Hash match analysis
                            st.markdown("#### Hash Analysis")
                            try:
                                md5_hashes = [getattr(f, 'md5', None) for f in compare_files]
                                sha1_hashes = [getattr(f, 'sha1', None) for f in compare_files]
                                sha256_hashes = [getattr(f, 'sha256', None) for f in compare_files]
                                
                                md5_match = len(set(h for h in md5_hashes if h)) <= 1
                                sha1_match = len(set(h for h in sha1_hashes if h)) <= 1
                                sha256_match = len(set(h for h in sha256_hashes if h)) <= 1
                                
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    if md5_match:
                                        st.success("✅ MD5 Match")
                                    else:
                                        st.error("❌ MD5 Mismatch")
                                with col2:
                                    if sha1_match:
                                        st.success("✅ SHA1 Match")
                                    else:
                                        st.error("❌ SHA1 Mismatch")
                                with col3:
                                    if sha256_match:
                                        st.success("✅ SHA256 Match")
                                    else:
                                        st.error("❌ SHA256 Mismatch")
                            except Exception as e:
                                st.error(f"Error in hash analysis: {str(e)}")
                    else:
                        st.warning("Could not find selected files for comparison.")
                except Exception as e:
                    st.error(f"Error during file comparison: {str(e)}")
            
            elif len(selected_files) == 1:
                st.info("Select at least 2 files to compare")
            else:
                st.info("Select files from the dropdown above to begin comparison")
        except Exception as e:
            st.error(f"Error in manual comparison setup: {str(e)}")

def main():
    st.set_page_config(
        page_title="DFIR Metadata Investigator",
        page_icon="🛡️",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    if 'files' not in st.session_state:
        st.session_state.files = []
    if 'processed' not in st.session_state:
        st.session_state.processed = False
    
    # Header
    st.title("🛡️ DFIR Metadata Investigator")
    st.markdown("*Digital Forensics & Incident Response - File Metadata Analysis Platform*")
    
    # Sidebar navigation
    with st.sidebar:
        st.markdown("## 🧭 Navigation")
        
        if st.session_state.processed:
            view = st.radio(
                "Select View",
                ["📁 Upload", "📊 Dashboard", "📈 Grouping", "🔍 Compare"],
                index=1
            )
        else:
            view = "📁 Upload"
            st.info("Upload files to unlock all features")
        
        # Case statistics
        if st.session_state.files:
            st.markdown("---")
            st.markdown("## 📈 Case Statistics")
            
            total_files = len(st.session_state.files)
            total_size = sum(f.size for f in st.session_state.files)
            
            st.metric("Total Files", total_files)
            st.metric("Total Size", format_bytes(total_size))
            
            # Extension breakdown
            ext_counts = defaultdict(int)
            for f in st.session_state.files:
                ext_counts[f.extension.upper()] += 1
            
            st.markdown("**Top Extensions:**")
            for ext, count in sorted(ext_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
                st.write(f"• {ext}: {count}")
    
    # Main content
    if view == "📁 Upload":
        render_upload_view()
    elif view == "📊 Dashboard" and st.session_state.files:
        render_dashboard()
    elif view == "📈 Grouping" and st.session_state.files:
        render_grouping()
    elif view == "🔍 Compare" and st.session_state.files:
        render_comparison()
    else:
        st.info("Please upload files first to access this feature.")

if __name__ == "__main__":
    main()
